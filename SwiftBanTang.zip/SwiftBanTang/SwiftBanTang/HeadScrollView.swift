//
//  HeadScrollView.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/28.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

import UIKit
import SDCycleScrollView

class HeadScrollView: UIView {

    var headScroll = SDCycleScrollView()
    
    
    
    override init(frame: CGRect) {
    
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        headScroll = SDCycleScrollView.init(frame: CGRect.init(x: 0, y: 0, width: self.width, height: 200), delegate: self, placeholderImage: UIImage.init(named: "PersonCenterbackImage"))
        headScroll.autoScrollTimeInterval = 3.0
        self.addSubview(headScroll)
        
    }
    
    func getScrollImgSource(source: Array<BannerModel>) {
        
        var picArr = Array<String>()
        
        for model: BannerModel in source {
            
            picArr.append(model.photo)
        }
        headScroll.imageURLStringsGroup = picArr
    }

    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension HeadScrollView: SDCycleScrollViewDelegate {

    func cycleScrollView(_ cycleScrollView: SDCycleScrollView!, didSelectItemAt index: Int) {
        
    }

}
