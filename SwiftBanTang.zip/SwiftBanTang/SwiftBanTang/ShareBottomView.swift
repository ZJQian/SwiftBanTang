//
//  ShareBottomView.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2017/1/5.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

import UIKit

class ShareBottomView: UIView {

    var viewsLabel = UILabel()
    var zanBtn = UIButton()
    
    
    override init(frame: CGRect) {
       
        super.init(frame: frame)
    
        setupSubViews()
    }
    
    func setupSubViews() {
        
        let imgArray = ["zan","pinglun","share"]
        let text = ["赞","评论","分享"]
        
        
        
        for index in 0...2 {
            
            let btn = UIButton.init(type: UIButtonType.custom)
            btn.frame = CGRect.init(x: CGFloat(index * 60), y: 0, width: 60, height: self.height)
            btn.setImage(UIImage.init(named: imgArray[index]), for: .normal)
            btn.setTitle(text[index], for: .normal)
            btn.imageEdgeInsets = UIEdgeInsets.init(top: 0, left: -5, bottom: 0, right: 0)
            btn.setTitleColor(UIColor.lightGray, for: .normal)
            btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
            btn.tag = index
            self.addSubview(btn)
            
            if index == 0 {
                self.zanBtn = btn
            }
        }
        
        viewsLabel = UILabel.init(frame: CGRect.init(x: SCREEN_WIDTH-60, y: 0, width: 60, height: self.height))
        viewsLabel.font = UIFont.systemFont(ofSize: 11)
        viewsLabel.textColor = UIColor.lightGray
        self.addSubview(viewsLabel)
    }
    
    func send(views: String, ispraise: Bool, praises: String) {
        
        

        if ispraise == true {
            self.zanBtn.setImage(UIImage.init(named: "zan2"), for: .normal)
        }
        if praises.isEmpty == false {
            self.zanBtn.setTitle(praises, for: .normal)
        }
        
        viewsLabel.text = "\(views) 浏览"
        
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
