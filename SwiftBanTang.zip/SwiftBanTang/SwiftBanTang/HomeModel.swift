//
//  HomeModel.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/28.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

import UIKit
import SwiftyJSON

class HomeModel: NSObject {

    var bannerArray = Array<Any>()
    
    init(dic: JSON) {
        
    
    }
    
}

class BannerModel: NSObject {
    
    var photo = String()
    
    init(dic: JSON) {
        self.photo = dic["photo"].stringValue
    }
    
}

class CategoryModel: NSObject {
    
    var title = String()
    
    init(dic: JSON) {
        self.title = dic["title"].stringValue
    }
    
}

class TopicModel: NSObject {
    var title = String()
    var pic = String()
    var praises = String()
    var views = String()
    var user : UserModel?
    
    
    init(dic: JSON) {
        
        self.pic = dic["pic"].stringValue
        self.title = dic["title"].stringValue
        self.praises = dic["praises"].stringValue
        self.views = dic["views"].stringValue
        self.user = UserModel.init(dic: dic["user"])
    }
}
class UserModel: NSObject {
    
    var nickname = String()
    
    init(dic: JSON) {
        self.nickname = dic["nickname"].stringValue
    }
    
}
