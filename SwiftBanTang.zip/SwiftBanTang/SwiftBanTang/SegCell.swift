//
//  SegCell.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2017/1/3.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

import UIKit
import SDWebImage

class SegCell: UITableViewCell {
    
    var img = UIImageView()
    var title = UILabel()
    
    var author = UILabel()
    var views = UILabel()
    var likes = UILabel()
    
    var view = UIView()
    
    
    
    
    

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        setupSubviews()
    }
    
    func setupSubviews() {
        
        
        img = UIImageView.init(frame: CGRect.init(x: 15, y: 15, width: SCREEN_WIDTH-15*2, height: 200))
        self.contentView.addSubview(img)
        
        
        title = UILabel.init(frame: CGRect.init(x: 15, y: img.bottom+10, width: img.width, height: 20))
        title.font = UIFont.systemFont(ofSize: 14)
        title.textAlignment = NSTextAlignment.center
        self.contentView.addSubview(title)
        
        
        view = UIView.init()
        view.center = CGPoint.init(x: img.center.x, y: title.bottom+20)
        view.bounds = CGRect.init(x: 0, y: 0, width: 0, height: 10);
        self.contentView.addSubview(view)
        
        author = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 10))
        author.font = UIFont.systemFont(ofSize: 10)
        view.addSubview(author)
        
        views = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 10))
        views.font = UIFont.systemFont(ofSize: 10)
        view.addSubview(views)
        
        likes = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 10))
        likes.font = UIFont.systemFont(ofSize: 10)
        view.addSubview(likes)
        
        
        
        
    }
    
    func sendModel(model: TopicModel) {
        
        self.img.sd_setImage(with: URL.init(string: model.pic), placeholderImage: UIImage.init(named: ""))
        self.title.text = model.title
        
        author.text = model.user?.nickname
        views.text = model.views
        likes.text = model.praises
        
        author.frame = CGRect.init(x: 0, y: 0, width: UILabel.getStringWidth(text: author.text!
            , size: 10), height: 10)
        
        views.frame = CGRect.init(x: author.right + 10, y: 0, width: UILabel.getStringWidth(text: model.views, size: 10), height: 10)
        
        likes.frame = CGRect.init(x: views.right + 10, y: 0, width: UILabel.getStringWidth(text: model.praises, size: 10), height: 10)
        
        
        view.bounds = CGRect.init(x: 0, y: 0, width: likes.right - author.left, height: 10)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
