//
//  SwiftBanTang-Bridging-Header.h
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/28.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

#ifndef SwiftBanTang_Bridging_Header_h
#define SwiftBanTang_Bridging_Header_h

#import <SDCycleScrollView/SDCycleScrollView.h>
#import <SDWebImage/UIImageView+WebCache.h>


#endif /* SwiftBanTang_Bridging_Header_h */
