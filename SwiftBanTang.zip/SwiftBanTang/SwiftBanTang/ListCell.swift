//
//  ListCell.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2017/1/4.
//  Copyright © 2017年 ZJQ. All rights reserved.
//

import UIKit

class ListCell: UITableViewCell {
    
    var img = UIImageView()
    var nameLabel = UILabel()
    var dateLabel = UILabel()
    var bigImg = UIImageView()
    var relationButton = UIButton()
    var contentLabel = UILabel()
    var shareView = ShareBottomView()
    
    
    

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
    
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        setupSubviews()
    }
    
    func setupSubviews() {
        
        img = UIImageView.init(frame: CGRect.init(x: 10, y: 10, width: 20, height: 20))
        img.layer.cornerRadius = 10
        img.layer.masksToBounds = true
        self.contentView.addSubview(img)
        
        
        nameLabel = UILabel.init(frame: CGRect.init(x: img.right+10, y: img.top, width: 0, height: 10))
        nameLabel.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(nameLabel)
        
        
        dateLabel = UILabel.init(frame: CGRect.init(x: img.right+10, y: nameLabel.bottom+5, width: 0, height: 8))
        dateLabel.font = UIFont.systemFont(ofSize: 8)
        dateLabel.textColor = UIColor.lightGray
        self.contentView.addSubview(dateLabel)
        
        
        bigImg = UIImageView.init(frame: CGRect.init(x: 15, y: img.bottom+20, width: SCREEN_WIDTH-15*2, height: SCREEN_WIDTH-15*2 - 50))
        self.contentView.addSubview(bigImg)
        
        
        
        relationButton = UIButton.init(type: .custom)
        //relationButton.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: 0, height: 10)
        relationButton.setTitleColor(UIColor.red, for: .normal)
        relationButton.titleLabel?.font = UIFont.systemFont(ofSize: 10)
        self.contentView.addSubview(relationButton)
        
        
        contentLabel = UILabel.init(frame: CGRect.init(x: relationButton.right, y: relationButton.top, width: 0, height: 10))
        contentLabel.font = UIFont.systemFont(ofSize: 10)
        contentLabel.numberOfLines = 0
        self.contentView.addSubview(contentLabel)
        
        
        let attentionBtn = UIButton.init(frame: CGRect.init(x: SCREEN_WIDTH-65, y: 15, width: 50, height: 20))
        attentionBtn.setTitle("+ 关注", for: .normal)
        attentionBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        attentionBtn.setTitleColor(UIColor.white, for: .normal)
        attentionBtn.layer.cornerRadius = 2
        attentionBtn.layer.masksToBounds = true
        attentionBtn.backgroundColor = UIColor.rgba(red: 255, green: 95, blue: 102, alpha: 1)
        self.contentView.addSubview(attentionBtn)
        
        
        shareView = ShareBottomView.init(frame: CGRect.init(x: 0, y:0, width: 0, height: 50))
        self.contentView.addSubview(shareView)
    }
    
    func sendModel(model: ListModel) {
        
        
        
        
        self.img.sd_setImage(with: URL.init(string: model.post.user.avatar.isEmpty == false ? model.post.user.avatar : model.topic.user.avatar))
        
        nameLabel.text = model.post.user.nickname.isEmpty == false ? model.post.user.nickname : model.topic.user.nickname
        dateLabel.text = model.post.datestr.isEmpty == false ? model.post.datestr : model.topic.datestr
        
        nameLabel.frame = CGRect.init(x: img.right+10, y: img.top, width: UILabel.getStringWidth(text: nameLabel.text!, size: 10), height: 10)
        dateLabel.frame = CGRect.init(x: img.right+10, y: nameLabel.bottom+5, width: UILabel.getStringWidth(text: dateLabel.text!, size: 8), height: 8)
        
        self.bigImg.sd_setImage(with: URL.init(string: model.post.middle_pic_url.isEmpty == false ? model.post.middle_pic_url : model.topic.share_pic))
        
        if model.post.middle_pic_url.isEmpty == false {
            self.bigImg.frame = CGRect.init(x: 15, y: img.bottom+20, width: SCREEN_WIDTH-15*2, height: SCREEN_WIDTH-15*2 - 50)
        }else{
        
            self.bigImg.frame = CGRect.init(x: 15, y: img.bottom+20, width: SCREEN_WIDTH-15*2, height: (SCREEN_WIDTH-15*2)*165/300)
        }
        
        if model.topic.title.isEmpty == false {
            
            if model.topic.relation.title.isEmpty == false {
               
                self.relationButton.setTitle("#\(model.topic.relation.title)", for: .normal)
                self.relationButton.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: UILabel.getStringWidth(text: "#\(model.topic.relation.title)", size: 10), height: 10)
                
                self.contentLabel.text = model.topic.title
                self.contentLabel.frame = CGRect.init(x: 15, y: relationButton.bottom+10, width: SCREEN_WIDTH - 15*2, height: 10)
            }else{
            
                self.relationButton.setTitle("\(model.topic.relation.title)", for: .normal)
                self.relationButton.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: UILabel.getStringWidth(text: "#\(model.topic.relation.title)", size: 10), height: 10)
                
                self.contentLabel.text = model.topic.title
                self.contentLabel.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: SCREEN_WIDTH - 15*2, height: 10)
            }
            
            
        }else{
           
            if model.post.relation.title.isEmpty == false {
                
                self.relationButton.setTitle("#\(model.post.relation.title)", for: .normal)
                self.relationButton.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: UILabel.getStringWidth(text: "#\(model.post.relation.title)", size: 10), height: 10)
                
                self.contentLabel.text = model.post.content
                self.contentLabel.frame = CGRect.init(x: relationButton.right+10, y: relationButton.top, width: SCREEN_WIDTH - 15*2, height: 10)
            }else{
            
                self.relationButton.setTitle("\(model.post.relation.title)", for: .normal)
                self.relationButton.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: UILabel.getStringWidth(text: "\(model.post.relation.title)", size: 10), height: 10)
                
                self.contentLabel.text = model.post.content
                self.contentLabel.frame = CGRect.init(x: 15, y: bigImg.bottom+10, width: SCREEN_WIDTH - 15*2, height: 10)
            }
            
        }
        
        
        if model.topic.title.isEmpty == false {
            self.shareView.frame = CGRect.init(x: 0, y: 300, width: SCREEN_WIDTH, height: 50)
            self.shareView.send(views: model.topic.views, ispraise: model.topic.ispraise, praises:model.topic.praises)
        }else{
            self.shareView.frame = CGRect.init(x: 0, y: 400, width: SCREEN_WIDTH, height: 50)
            self.shareView.send(views: model.post.dynamic.views, ispraise: model.post.dynamic.ispraise, praises:model.post.dynamic.praises)
        }
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
