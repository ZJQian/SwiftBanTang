//
//  SearchHeadView.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2017/1/3.
//  Copyright © 2017年 ZJQ. All rights reserved.
//


private let activityCell = "activityCell"

import UIKit

class SearchHeadView: UIView {

    var img = UIImageView()
    var activityArray = Array<ActivityModel>()
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor.init(colorLiteralRed: 241/255.0, green: 241/255.0, blue: 241/255.0, alpha: 1)
        setupSubviews()
    }
    
    func setupSubviews() {
        
        img = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 100))
        self.addSubview(img)
        
        let array = ["达人榜","文章榜","晒单榜"]
        let imgArray = ["daren","wenzhang","shaidan"]
        
        
        for i in 0...2 {
            
            let btn = UIButton.init(type: UIButtonType.custom)
            btn.frame = CGRect.init(x: CGFloat(i) * SCREEN_WIDTH/3, y: img.bottom, width: SCREEN_WIDTH/3, height: 80)
            btn.backgroundColor = UIColor.white
            self.addSubview(btn)
            
            let imgView = UIImageView.init()
            imgView.frame = CGRect.init(x: (SCREEN_WIDTH/3-30)/2, y: 15, width: 30, height: 30)
            imgView.image = UIImage.init(named: imgArray[i])
            btn.addSubview(imgView)
            
            
            let label = UILabel.init(frame: CGRect.init(x: 0, y: imgView.bottom+10, width: SCREEN_WIDTH/3, height: 20))
            label.font = UIFont.systemFont(ofSize: 14)
            label.textAlignment = NSTextAlignment.center
            label.text = array[i]
            btn.addSubview(label)
        }
        
        let title = UILabel.init(frame: CGRect.init(x: 0, y: img.bottom+90, width: SCREEN_WIDTH, height: 40))
        title.textAlignment = NSTextAlignment.center
        title.font = UIFont.systemFont(ofSize: 15)
        title.textColor = UIColor.darkText
        title.text = "热门活动"
        title.backgroundColor = UIColor.white
        self.addSubview(title)
        
        
        
    }
    
    func sendModel(model: SearchModel) {
        
        self.img.sd_setImage(with: URL.init(string: model.banner[0].photo), placeholderImage: UIImage.init(named: ""))
        self.activityArray = model.activity_list

        var height = CGFloat()
        
        let count = self.activityArray.count%2
        if count == 0 {
            height = CGFloat(self.activityArray.count/2*80)
        }else{
        
            height = CGFloat(self.activityArray.count/2 + 1)*80
        }
        
        print(self.activityArray.count%2)
        let layout = UICollectionViewFlowLayout.init()
        layout.itemSize = CGSize.init(width: (SCREEN_WIDTH-1)/2, height: 80)
        layout.minimumLineSpacing = 1
        layout.minimumInteritemSpacing = 1
        layout.sectionInset = UIEdgeInsetsMake(1, 0, 1, 0)
        let collectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: img.bottom+130, width: SCREEN_WIDTH, height: height), collectionViewLayout: layout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(ActivityCell.self, forCellWithReuseIdentifier: activityCell)
        collectionView.backgroundColor = UIColor.clear
        collectionView.isScrollEnabled = false
        self.addSubview(collectionView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension SearchHeadView: UICollectionViewDelegate,UICollectionViewDataSource {

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.activityArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: activityCell, for: indexPath) as! ActivityCell
        cell.sendModel(model: self.activityArray[indexPath.item])
        return cell
    }
}
