//
//  NavView.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/30.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

import UIKit

class NavView: UIView {

    var tableViews = Array<UITableView>()
    
    override init(frame: CGRect) {
    
       
        super.init(frame: frame)
        
        self.addSubview(self.searchBar)
        self.addSubview(self.searchBtn)
        self.addSubview(self.emailBtn)
    }
    
    override func willMove(toSuperview newSuperview: UIView?) {
        
        super.willMove(toSuperview: newSuperview)
        
        for table in self.tableViews {
            
            table.addObserver(self, forKeyPath: "contentOffset", options: .new, context: nil)
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
        if (!(keyPath == "contentOffset")) {
            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
            return;
        }
        
        let tableView = object as! UITableView
        let tableViewoffsetY = tableView.contentOffset.y

        self.backgroundColor = UIColor.white.withAlphaComponent(min(1, tableViewoffsetY/136))
        
        if tableViewoffsetY < 125 {
            UIView.animate(withDuration: 0.25, animations: {
            
                self.searchBtn.isHidden = false
                self.emailBtn.setBackgroundImage(UIImage.init(named: "home_email_black"), for: .normal)
                self.searchBar.frame = CGRect.init(x: -(self.width-60), y: 30, width: self.width-80, height: 30)
                self.emailBtn.alpha = 1 - (min(1, tableViewoffsetY/136))
                self.searchBtn.alpha = 1 - (min(1, tableViewoffsetY/136))
                
            })
        }else{
        
            UIView.animate(withDuration: 0.25, animations: {
            
                self.searchBar.frame = CGRect.init(x: 20, y: 30, width: self.width-80, height: 30)
                self.searchBtn.isHidden = true
                self.emailBtn.alpha = 1
                self.emailBtn.setBackgroundImage(UIImage.init(named: "home_email_red"), for: .normal)
            })
        }

    }
    
    lazy var searchBar: UISearchBar = {
        let search: UISearchBar = UISearchBar.init(frame: CGRect.init(x: -(self.width-60), y: 30, width: self.width-80, height: 30))
        search.placeholder = "搜索值得买的好物"
        search.layer.cornerRadius = 15
        search.layer.masksToBounds = true
        
        search.setSearchFieldBackgroundImage(UIImage.image(color: UIColor.lightGray.withAlphaComponent(0.4), size: search.frame.size), for: .normal)
        search.setBackgroundImage(UIImage.image(color: UIColor.lightGray.withAlphaComponent(0.4), size: search.frame.size), for: UIBarPosition.any, barMetrics: .default)
        
        let tf = search.value(forKey: "_searchField") as! UITextField
        tf.textColor = UIColor.white
        tf.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        
        return search
    }()
    
    lazy var searchBtn: UIButton = {
        let btn = UIButton.init(type: UIButtonType.custom)
        btn.frame = CGRect.init(x: 20, y: 30, width: 30, height: 30)
        btn.setBackgroundImage(UIImage.init(named: "home_search_icon"), for: .normal)
        return btn
    }()
    
    lazy var emailBtn: UIButton = {
        let btn = UIButton.init(type: UIButtonType.custom)
        btn.frame = CGRect.init(x: self.width - 45, y: 30, width: 30, height: 30)
        btn.setBackgroundImage(UIImage.init(named: "home_email_black"), for: .normal)
        return btn
    }()
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
