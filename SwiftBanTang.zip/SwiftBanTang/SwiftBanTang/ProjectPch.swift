
//
//  ProjectPch.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/28.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

import UIKit


let SCREEN_WIDTH = UIScreen.main.bounds.width
let SCREEN_HEIGHT = UIScreen.main.bounds.height

let BASE_URL = "http://open3.bantangapp.com/"

///滚播图的  url
let SCROLL_IMG = "recommend/index?"

///搜索界面的 url
let SAERCH_URL = "post/index/index?"

let SEARCH_LIST = "post/index/listByNew?"


let headSegmentArray = ["推荐","最新","热门","礼物","美食","生活","设计感","家居","数码","阅读","学生党","上班族","美妆","护理","运动户外","健康"]
		
