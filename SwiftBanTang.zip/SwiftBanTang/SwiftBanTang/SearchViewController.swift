//
//  SearchViewController.swift
//  SwiftBanTang
//
//  Created by ZJQ on 2016/12/28.
//  Copyright © 2016年 ZJQ. All rights reserved.
//

private let listCell = "listCell"

import UIKit
import SwiftyJSON

class SearchViewController: RootViewController {

    var listArray = Array<ListModel>()
    
    
    lazy var headView: SearchHeadView = {
        let headview = SearchHeadView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 0))
        return headview
    }()
    
    lazy var tableView: UITableView = {
        let table = UITableView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT), style: .plain)
        table.delegate = self
        table.dataSource = self
        return table
    }()

    lazy var searchBar: UISearchBar = {
        let search: UISearchBar = UISearchBar.init(frame: CGRect.init(x: -(SCREEN_WIDTH-60), y: 30, width: SCREEN_WIDTH-80, height: 30))
        search.placeholder = "搜索值得买的好物"
        search.layer.cornerRadius = 15
        search.layer.masksToBounds = true
        
        search.setSearchFieldBackgroundImage(UIImage.image(color: UIColor.lightGray.withAlphaComponent(0.4), size: search.frame.size), for: .normal)
        search.setBackgroundImage(UIImage.image(color: UIColor.lightGray.withAlphaComponent(0.4), size: search.frame.size), for: UIBarPosition.any, barMetrics: .default)
        
        let tf = search.value(forKey: "_searchField") as! UITextField
        tf.textColor = UIColor.white
        tf.setValue(UIColor.white, forKeyPath: "_placeholderLabel.textColor")
        
        return search
    }()

    override func viewDidLoad() {
        super.viewDidLoad()

        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationItem.titleView = self.searchBar
        
        loadData()
        loadList()
        self.view.addSubview(self.tableView)

    }

    func loadData() {
        
        let para = ["app_id":"com.jzyd.BanTang",
                    "app_installtime":"1482905598",
                    "app_versions":"5.9.5",
                    "channel_name":"appStore",
                    "client_id":"bt_app_ios",
                    "client_secret":"9c1e6634ce1c5098e056628cd66a17a5",
                    "oauth_token":"4150e754a624ecdc255ad1d13f6287bc",
                    //"last_get_time":"1463238932",
            "os_versions":"10.2",
            "screensize":"750",
            "track_device_info":"iPhone8,4",
            "track_device_uuid":"DE964894-8C6F-48BF-9F6C-A47167353EAC",
            "track_deviceid":"BAEA9AD2-16E3-4D12-8E28-4EB9F15A1412",
            "track_user_id":"2777434",
            "v":"24"
            //"page":"0",
            //"pagesize":"20"
        ]
        
        NetRequest.sharedInstance.getRequest(urlString: BASE_URL.appending(SAERCH_URL), params: para, finished: {(response, error) in
            
            let json = JSON(response!)
            
            let model = SearchModel.init(dic: json["data"])
            
            var height = CGFloat()
            
            let count = model.activity_list.count%2
            if count == 0 {
                height = CGFloat(model.activity_list.count/2*80)
            }else{
                
                height = CGFloat(model.activity_list.count/2 + 1)*80
            }
            self.headView.frame = CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: height+240)
            self.tableView.tableHeaderView = self.headView
            self.headView.sendModel(model: model)
            
            self.tableView.reloadData()
        })
    }
    
    func loadList() {
        
        let para = ["app_id":"com.jzyd.BanTang",
                    "app_installtime":"1482905598",
                    "app_versions":"5.9.5",
                    "channel_name":"appStore",
                    "client_id":"bt_app_ios",
                    "client_secret":"9c1e6634ce1c5098e056628cd66a17a5",
                    "oauth_token":"4150e754a624ecdc255ad1d13f6287bc",
                    "os_versions":"10.2",
                    "screensize":"750",
                    "track_device_info":"iPhone8,4",
                    "track_device_uuid":"DE964894-8C6F-48BF-9F6C-A47167353EAC",
                    "track_deviceid":"BAEA9AD2-16E3-4D12-8E28-4EB9F15A1412",
                    "track_user_id":"2777434",
                    "v":"24",
                    "page":"0",
                    "pagesize":"20"
        ]
        
        NetRequest.sharedInstance.getRequest(urlString: BASE_URL.appending(SEARCH_LIST), params: para, finished: {(response, error) in
            
            let json = JSON(response!)
            print(json)
            
            for (_,subJosn):(String,JSON) in json["data"]["list"] {
            
                let model = ListModel.init(dic: subJosn)
                self.listArray.append(model)
            }

            self.tableView.reloadData()
        })
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension SearchViewController: UITableViewDelegate,UITableViewDataSource {

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listArray.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: listCell) as? ListCell
        if cell == nil {
            cell = ListCell.init(style: .default, reuseIdentifier: listCell)
        }
        cell?.sendModel(model: self.listArray[indexPath.row])
        return cell!
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let view = SearchSegmentView.init(frame: CGRect.init(x: 0, y: 0, width: SCREEN_WIDTH, height: 30))
        view.backgroundColor = UIColor.white
        
        return view
        
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        let model = self.listArray[indexPath.row]
        if model.post.middle_pic_url.isEmpty == true {
            
            return 350
        }else{
        
            return 450
        }
    }

}
